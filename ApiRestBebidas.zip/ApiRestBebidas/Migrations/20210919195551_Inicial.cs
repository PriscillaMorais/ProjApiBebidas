﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace ApiRestBebidas.Migrations
{
    public partial class Inicial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterDatabase()
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Genero",
                columns: table => new
                {
                    GeneId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    GeneNome = table.Column<string>(type: "varchar(250)", maxLength: 250, nullable: true)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    GeneAtivo = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Genero", x => x.GeneId);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "CashBack",
                columns: table => new
                {
                    CashId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    GeneroGeneId = table.Column<int>(type: "int", nullable: true),
                    CashSegunda = table.Column<decimal>(type: "decimal(65,30)", nullable: false),
                    CashTerca = table.Column<decimal>(type: "decimal(65,30)", nullable: false),
                    CashQuarta = table.Column<decimal>(type: "decimal(65,30)", nullable: false),
                    CashQuinta = table.Column<decimal>(type: "decimal(65,30)", nullable: false),
                    CashSabado = table.Column<decimal>(type: "decimal(65,30)", nullable: false),
                    CashDomingo = table.Column<decimal>(type: "decimal(65,30)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CashBack", x => x.CashId);
                    table.ForeignKey(
                        name: "FK_CashBack_Genero_GeneroGeneId",
                        column: x => x.GeneroGeneId,
                        principalTable: "Genero",
                        principalColumn: "GeneId",
                        onDelete: ReferentialAction.Restrict);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Produtos",
                columns: table => new
                {
                    ProdId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    ProdNome = table.Column<string>(type: "varchar(250)", maxLength: 250, nullable: true)
                        .Annotation("MySql:CharSet", "utf8mb4"),
                    ProdPreco = table.Column<decimal>(type: "decimal(10,2)", precision: 10, scale: 2, nullable: false),
                    ProdEstoque = table.Column<int>(type: "int", nullable: false),
                    ProdAtivo = table.Column<int>(type: "int", nullable: false),
                    GeneroGeneId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Produtos", x => x.ProdId);
                    table.ForeignKey(
                        name: "FK_Produtos_Genero_GeneroGeneId",
                        column: x => x.GeneroGeneId,
                        principalTable: "Genero",
                        principalColumn: "GeneId",
                        onDelete: ReferentialAction.Restrict);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.CreateTable(
                name: "Venda",
                columns: table => new
                {
                    VendId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    ProdutoProdId = table.Column<int>(type: "int", nullable: true),
                    VendQtde = table.Column<int>(type: "int", nullable: false),
                    VendDataVenda = table.Column<DateTime>(type: "datetime(6)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Venda", x => x.VendId);
                    table.ForeignKey(
                        name: "FK_Venda_Produtos_ProdutoProdId",
                        column: x => x.ProdutoProdId,
                        principalTable: "Produtos",
                        principalColumn: "ProdId",
                        onDelete: ReferentialAction.Restrict);
                })
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.InsertData(
                table: "Genero",
                columns: new[] { "GeneId", "GeneAtivo", "GeneNome" },
                values: new object[,]
                {
                    { 1, 1, "SKOLL" },
                    { 2, 1, "BRAHMA" },
                    { 3, 1, "STELLA" },
                    { 4, 1, "BOHEMIA" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_CashBack_GeneroGeneId",
                table: "CashBack",
                column: "GeneroGeneId");

            migrationBuilder.CreateIndex(
                name: "IX_Produtos_GeneroGeneId",
                table: "Produtos",
                column: "GeneroGeneId");

            migrationBuilder.CreateIndex(
                name: "IX_Venda_ProdutoProdId",
                table: "Venda",
                column: "ProdutoProdId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "CashBack");

            migrationBuilder.DropTable(
                name: "Venda");

            migrationBuilder.DropTable(
                name: "Produtos");

            migrationBuilder.DropTable(
                name: "Genero");
        }
    }
}
