﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ApiRestBebidas.Data;
using Canducci.Pagination;
using System.Web.Http.OData;

namespace ApiRestBebidas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CashBacksController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CashBacksController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/CashBacks
        [HttpGet]
        [EnableQuery]
        public async Task<ActionResult<IEnumerable<CashBack>>> GetCashBack()
        {
            return await _context.CashBack.ToListAsync();
        }

        [HttpGet("compaginacao/{page?}")]
        public async Task<IActionResult> GetSourcePaginated(int? page)
        {
            page ??= 1;
            if (page <= 0) page = 1;

            var result = await _context
               .CashBack
               .AsNoTracking()
               .OrderBy(c => c.CashId)
               .ToPaginatedRestAsync(page.Value, 5);
            return Ok(result);
        }

        //[HttpGet]
        //[EnableQuery]
        //public IQueryable<CashBack> GetCashbackOrdenar()
        //{
        //    return _context.CashBack.AsQueryable<CashBack>();
        //}

        // GET: api/CashBacks/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CashBack>> GetCashBack(int id)
        {
            var cashBack = await _context.CashBack.FindAsync(id);

            if (cashBack == null)
            {
                return NotFound();
            }

            return cashBack;
        }

        // PUT: api/CashBacks/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCashBack(int id, CashBack cashBack)
        {
            if (id != cashBack.CashId)
            {
                return BadRequest();
            }

            _context.Entry(cashBack).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CashBackExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CashBacks
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<CashBack>> PostCashBack(CashBack cashBack)
        {
            _context.CashBack.Add(cashBack);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCashBack", new { id = cashBack.CashId }, cashBack);
        }

        // DELETE: api/CashBacks/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<CashBack>> DeleteCashBack(int id)
        {
            var cashBack = await _context.CashBack.FindAsync(id);
            if (cashBack == null)
            {
                return NotFound();
            }

            _context.CashBack.Remove(cashBack);
            await _context.SaveChangesAsync();

            return cashBack;
        }

        private bool CashBackExists(int id)
        {
            return _context.CashBack.Any(e => e.CashId == id);
        }
    }
}
