﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ApiRestBebidas.Data;
using System;

namespace ApiRestBebidas.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VendasController : ControllerBase
    {
        private readonly AppDbContext _context;

        public VendasController(AppDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Obter todas as vendas.
        /// </summary>
        /// <response code="200">A lista de vendas foi obtida com sucesso</response>
        /// <response code="500">Ocorreu um erro ao obter a listagem das vendas.</response>
        // GET: api/Vendas
        [HttpGet]
        [ProducesResponseType(typeof(List<Venda>), 200)]
        [ProducesResponseType(500)]
        public async Task<ActionResult<IEnumerable<Venda>>> GetVenda()
        {
            return await _context.Venda.ToListAsync();
        }

        /// <summary>
        /// Obter um venda específico por ID.
        /// </summary>
        /// <param name="id">ID da venda.</param>
        /// <response code="200">A venda foi obtida com sucesso.</response>
        /// <response code="404">Não foi encontrada vanda com ID especificado.</response>
        /// <response code="500">Ocorreu um erro ao obter a venda informada.</response>
        // GET: api/Vendas/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Venda>> GetVenda(int id)
        {
            var venda = await _context.Venda.FindAsync(id);

            if (venda == null)
            {
                return NotFound(new { message = "A venda informada não foi encontrada." });
            }

            return Ok(venda);
        }

        // PUT: api/Vendas/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutVenda(int id, Venda venda)
        {
            if (id != venda.VendId)
            {
                return BadRequest();
            }

            _context.Entry(venda).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!VendaExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Vendas
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Venda>> PostVenda(Venda venda, string diaSemana)
        {

            venda.TotalVenda = _context.TotalDaVenda(DateTime.Now.DayOfWeek.ToString(), venda);
            _context.Venda.Add(venda);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetVenda", new { id = venda.VendId }, venda);
        }

        // DELETE: api/Vendas/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Venda>> DeleteVenda(int id)
        {
            var venda = await _context.Venda.FindAsync(id);
            if (venda == null)
            {
                return NotFound();
            }

            _context.Venda.Remove(venda);
            await _context.SaveChangesAsync();

            return venda;
        }

        private bool VendaExists(int id)
        {
            return _context.Venda.Any(e => e.VendId == id);
        }
    }
}
