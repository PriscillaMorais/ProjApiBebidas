﻿using System;

namespace ApiRestBebidas.Data
{
    public class Venda
    {
        public int VendId { get; set; }
        public Produto Produto { get; set; }
        public int VendQtde { get; set; }
        public DateTime VendDataVenda { get; set; }
        public decimal TotalVenda { get; set; }
    }
}
