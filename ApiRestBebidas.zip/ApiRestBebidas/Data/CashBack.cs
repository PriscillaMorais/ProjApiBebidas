﻿

namespace ApiRestBebidas.Data
{
    public class CashBack
    {
        public int CashId { get; set; }
        public Genero Genero { get; set; }
        public decimal CashSegunda { get; set; }
        public decimal CashTerca { get; set; }
        public decimal CashQuarta { get; set; }
        public decimal CashQuinta { get; set; }
        public decimal CashSabado { get; set; }
        public decimal CashDomingo { get; set; }
    }
}
