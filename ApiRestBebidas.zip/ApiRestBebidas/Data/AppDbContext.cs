﻿using Microsoft.EntityFrameworkCore;

namespace ApiRestBebidas.Data
{
    public class AppDbContext : DbContext
    {

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {

        }
        public DbSet<Produto> Produtos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Genero>()
              .HasKey(p => p.GeneId);

            modelBuilder.Entity<Genero>()
              .Property(p => p.GeneNome)
            .HasMaxLength(250);

            modelBuilder.Entity<Genero>()
                 .HasData(
                      new Genero { GeneId = 1, GeneNome = "SKOLL", GeneAtivo = 1 },
                      new Genero { GeneId = 2, GeneNome = "BRAHMA", GeneAtivo = 1 },
                      new Genero { GeneId = 3, GeneNome = "STELLA", GeneAtivo = 1 },
                      new Genero { GeneId = 4, GeneNome = "BOHEMIA", GeneAtivo = 1 }
                 );

            modelBuilder.Entity<Produto>()
                .HasKey(p => p.ProdId);

            modelBuilder.Entity<Produto>()
                .Property(p => p.ProdNome)
                .HasMaxLength(250);

            modelBuilder.Entity<Produto>()
                .Property(p => p.ProdPreco)
                .HasPrecision(10, 2);

            //= modelBuilder.Entity<Produto>()
            //    .HasData(
            //         new Produto { ProdId = 1, ProdNome = "LATINHA 269ML", ProdPreco = 2.35M, ProdEstoque = 10, Genero = 1 },
            //         new Produto { ProdId = 2, ProdNome = "LONG NECK 275ML", ProdPreco = 3.29M, ProdEstoque = 50, Genero = 1 },
            //         new Produto { ProdId = 3, ProdNome = "BRAHMA PILSEN", ProdPreco = 4.29M, ProdEstoque = 50, Genero = 2 },
            //         new Produto { ProdId = 4, ProdNome = "STELLA ARTOIS", ProdPreco = 5.29M, ProdEstoque = 50, Genero = 3 },
            //         new Produto { ProdId = 5, ProdNome = "AURA LAGER", ProdPreco = 7.59M, ProdEstoque = 50, Genero = 4 }
            //    );

            modelBuilder.Entity<CashBack>()
                .HasKey(p => p.CashId);

            modelBuilder.Entity<Venda>()
                .HasKey(p => p.VendId);
        }

        public DbSet<Venda> Venda { get; set; }

        public decimal TotalDaVenda (string dia, Venda venda) {

            decimal total = 0;
            decimal cash = new decimal();

            switch (dia)
            {
                case "segunda":
                    cash = 55;
                    total = venda.Produto.ProdPreco * venda.VendQtde * cash / 100;
                 break;
                case "terca":
                    break;
                case "quarta":
                    break;
                case "quinta":
                    break;
                case "sexta":
                    break;
                case "sabado":
                    break;
                case "domingo":
                    break;

            }

            return total;

        }

        public DbSet<CashBack> CashBack { get; set; }

        public DbSet<Genero> Genero { get; set; }

    }


}
