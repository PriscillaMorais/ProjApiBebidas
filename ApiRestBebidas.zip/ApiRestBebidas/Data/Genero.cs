﻿
using System.Collections.Generic;

namespace ApiRestBebidas.Data
{
    public class Genero
    {
        public int GeneId { get; set; }
        public string GeneNome { get; set; }
        public int GeneAtivo { get; set; }
        public IList<CashBack> Cashbacks { get; set; }
    }
}