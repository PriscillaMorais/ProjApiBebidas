﻿
namespace ApiRestBebidas.Data
{
    public class Produto
    {
        public int ProdId { get; set; }
        public string ProdNome { get; set; }
        public decimal ProdPreco { get; set; }
        public int ProdEstoque { get; set; }
        public int ProdAtivo { get; set; }
        public Genero Genero { get; set; }


    }
}
